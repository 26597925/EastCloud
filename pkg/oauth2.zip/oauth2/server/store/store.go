package store

import (
	"sapi/pkg/logger"
	"sapi/pkg/store"
	"sapi/pkg/store/buntdb"
)

func GetDefaultStore() store.Store{
	store, err := buntdb.NewStore(":memory:")
	if err != nil {
		logger.Error(err)
		return nil
	}

	return store
}
