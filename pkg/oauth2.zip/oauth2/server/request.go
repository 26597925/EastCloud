package server

import (
	"net/http"
	"sapi/pkg/oauth2/api"
	"sapi/pkg/oauth2/server/token"
)

type request struct {

}

func (rep *request) ValidationAuthorizeRequest(r *http.Request) (*AuthorizeRequest, error) {
	redirectURI := r.FormValue("redirect_uri")
	clientID := r.FormValue("client_id")
	if !(r.Method == "GET" || r.Method == "POST") ||
		clientID == "" {
		return nil, ErrInvalidRequest
	}

	resType := api.ResponseType(r.FormValue("response_type"))
	if resType.String() == "" {
		return nil, ErrUnsupportedResponseType
	} else if allowed := o.checkResponseType(resType); !allowed {
		return nil, ErrUnauthorizedClient
	}

	req := &AuthorizeRequest{
		RedirectURI:  redirectURI,
		ResponseType: resType,
		ClientID:     clientID,
		State:        r.FormValue("state"),
		Scope:        r.FormValue("scope"),
	}
	return req, nil
}

func (rep *request) ValidationTokenRequest(r *http.Request) (*TokenRequest, error) {
	if v := r.Method; !(v == "POST" ||
		(o.opts.AllowGetAccessRequest && v == "GET")) {
		return nil, ErrInvalidRequest
	}

	gt := api.GrantType(r.FormValue("grant_type"))
	if gt.String() == "" {
		return nil, ErrUnsupportedGrantType
	}

	clientID, clientSecret, err := o.ClientInfoHandler(r)
	if err != nil {
		return nil, err
	}

	tr := &TokenRequest{
		GrantType:    gt,
		ClientID:     clientID,
		ClientSecret: clientSecret,
	}

	switch gt {
	case api.AuthorizationCode:
		tr.RedirectURI = r.FormValue("redirect_uri")
		tr.Code = r.FormValue("code")
		if tr.RedirectURI == "" ||
			tr.Code == "" {
			return nil, ErrInvalidRequest
		}
	case api.PasswordCredentials:
		tr.Scope = r.FormValue("scope")
		username, password := r.FormValue("username"), r.FormValue("password")
		if username == "" || password == "" {
			return nil, ErrInvalidRequest
		}

		userID, err := o.PasswordAuthorizationHandler(username, password)
		if err != nil {
			return nil, err
		} else if userID == "" {
			return nil, ErrInvalidGrant
		}
		tr.UserID = userID
	case api.ClientCredentials:
		tr.Scope = r.FormValue("scope")
	case api.Refreshing:
		tr.Refresh = r.FormValue("refresh_token")
		tr.Scope = r.FormValue("scope")
		if tr.Refresh == "" {
			return nil, ErrInvalidRequest
		}
	}

	return tr, nil
}

func (rep *request) BearerAuth(r *http.Request) (string, bool) {
	return "", true
}

func (rep *request) ValidationBearerToken(r *http.Request) (*token.Token, error) {
	return nil, nil
}