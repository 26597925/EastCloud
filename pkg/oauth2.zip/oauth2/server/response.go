package server

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"sapi/pkg/oauth2/api"
)

type Response struct {
	Writer http.ResponseWriter
}

func (res *Response) GetRedirectURI(req *AuthorizeRequest, data map[string]interface{}) (string, error) {
	u, err := url.Parse(req.RedirectURI)
	if err != nil {
		return "", err
	}

	q := u.Query()
	if req.State != "" {
		q.Set("state", req.State)
	}

	for k, v := range data {
		q.Set(k, fmt.Sprint(v))
	}

	switch req.ResponseType {
	case api.Code:
		u.RawQuery = q.Encode()
	case api.Token:
		u.RawQuery = ""
		fragment, err := url.QueryUnescape(q.Encode())
		if err != nil {
			return "", err
		}
		u.Fragment = fragment
	}

	return u.String(), nil
}

func (res *Response) Redirect(w http.ResponseWriter, req *AuthorizeRequest, data map[string]interface{}) error {
	uri, err := res.GetRedirectURI(req, data)
	if err != nil {
		return err
	}

	w.Header().Set("Location", uri)
	w.WriteHeader(302)
	return nil
}

func (res *Response) RedirectError(w http.ResponseWriter, req *AuthorizeRequest, err error) error {
	if req == nil {
		return err
	}
	data, _:= res.errorData(err)
	return res.redirect(w, req, data)
}

func (res *Response) ErrorData(err error) (map[string]interface{}, int) {
	data := make(map[string]interface{})
	data["error"] = err.Error()

	var statusCode int
	if statusCode = StatusCodes[err]; statusCode == 0 {
		data["error_code"] = statusCode
		statusCode = http.StatusInternalServerError
	}

	if v := Descriptions[err]; v != "" {
		data["error_description"] = v
	}

	return data, statusCode
}

func (res *Response) outputTokenError(w http.ResponseWriter, err error) error {
	data, statusCode := res.errorData(err)
	return res.outputToken(w, data, statusCode)
}

func (res *Response) outputToken(w http.ResponseWriter, data map[string]interface{}, statusCode ...int) error {
	w.Header().Set("Content-Type", "application/json;charset=UTF-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Pragma", "no-cache")

	status := http.StatusOK
	if len(statusCode) > 0 && statusCode[0] > 0 {
		status = statusCode[0]
	}

	w.WriteHeader(status)
	return json.NewEncoder(w).Encode(data)
}