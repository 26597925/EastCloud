package server

import (
	"sapi/pkg/oauth2/api"
)

type AuthorizeRequest struct {
	ResponseType   api.ResponseType
	ClientID       string
	ClientSecret   string
	Scope          string
	RedirectURI    string
	State          string

	UserID         string
}

type TokenRequest struct {
	GrantType	   api.GrantType
	ClientID       string
	ClientSecret   string
	Code           string
	RedirectURI    string

	Scope          string
	Refresh        string
	UserID         string
}