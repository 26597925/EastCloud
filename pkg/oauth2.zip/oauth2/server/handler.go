package server

import (
	"net/http"
	"net/url"
	"strings"
)

func ClientFormHandler(r *http.Request) (string, string, error) {
	clientID := r.Form.Get("client_id")
	if clientID == "" {
		return "", "", ErrInvalidClient
	}
	clientSecret := r.Form.Get("client_secret")
	return clientID, clientSecret, nil
}

func ClientBasicHandler(r *http.Request) (string, string, error) {
	username, password, ok := r.BasicAuth()
	if !ok {
		return "", "", ErrInvalidClient
	}
	return username, password, nil
}

func ValidateURIHandler(baseURI string, redirectURI string) error {
	base, err := url.Parse(baseURI)
	if err != nil {
		return err
	}

	redirect, err := url.Parse(redirectURI)
	if err != nil {
		return err
	}
	if !strings.HasSuffix(redirect.Host, base.Host) {
		return ErrInvalidRedirectURI
	}
	return nil
}

func UserAuthorizationHandler(w http.ResponseWriter, r *http.Request) (string, error) {
	return "", ErrAccessDenied
}

func PasswordAuthorizationHandler(username, password string) (string, error) {
	return "", ErrAccessDenied
}