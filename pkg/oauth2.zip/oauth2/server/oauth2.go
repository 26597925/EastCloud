package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"sapi/pkg/oauth2/api"
	"sapi/pkg/oauth2/server/generates"
	"sapi/pkg/oauth2/server/token"
	"strings"
	"time"
)

type Oauth2 struct {
	opts *Options

	ClientInfoHandler            func(r *http.Request) (clientID, clientSecret string, err error)
	ExtensionFieldsHandler		 func(t *token.Token) (fieldsValue map[string]interface{})

	ClientAuthorizedHandler      func(clientID string, grant api.GrantType) (allowed bool, err error)
	ClientScopeHandler			 func(clientID, scope string) (allowed bool, err error)
	RefreshingScopeHandler func(newScope, oldScope string) (allowed bool, err error)

	UserAuthorizationHandler     func(w http.ResponseWriter, r *http.Request) (userID string, err error)
	PasswordAuthorizationHandler func(username, password string) (userID string, err error)
	AuthorizeScopeHandler func(w http.ResponseWriter, r *http.Request) (scope string, err error)

	ValidateURIHandler			 func(baseURI, redirectURI string) error
}

func NewOauth2(opts *Options) *Oauth2{
	if opts.tokenConfigs == nil {
		opts.tokenConfigs = GetDefaultTokenConfig()
	}

	oauth2 := &Oauth2{opts:opts}

	if oauth2.opts.AccessGenerate == nil {
		oauth2.opts.AccessGenerate = generates.NewBaseAccess()
	}

	if oauth2.opts.AuthorizeGenerate == nil {
		oauth2.opts.AuthorizeGenerate = generates.NewAuthorize()
	}

	oauth2.ValidateURIHandler = ValidateURIHandler
	oauth2.ClientInfoHandler = ClientBasicHandler
	oauth2.UserAuthorizationHandler = UserAuthorizationHandler
	oauth2.PasswordAuthorizationHandler = PasswordAuthorizationHandler

	return oauth2
}

func (o *Oauth2) SetUserAuthorizationHandler(handler func(w http.ResponseWriter, r *http.Request) (userID string, err error)) {
	o.UserAuthorizationHandler = handler
}


func (o *Oauth2) ValidationAuthorizeRequest(r *http.Request) (*AuthorizeRequest, error) {
	redirectURI := r.FormValue("redirect_uri")
	clientID := r.FormValue("client_id")
	if !(r.Method == "GET" || r.Method == "POST") ||
		clientID == "" {
		return nil, ErrInvalidRequest
	}

	resType := api.ResponseType(r.FormValue("response_type"))
	if resType.String() == "" {
		return nil, ErrUnsupportedResponseType
	} else if allowed := o.checkResponseType(resType); !allowed {
		return nil, ErrUnauthorizedClient
	}

	req := &AuthorizeRequest{
		RedirectURI:  redirectURI,
		ResponseType: resType,
		ClientID:     clientID,
		State:        r.FormValue("state"),
		Scope:        r.FormValue("scope"),
	}
	return req, nil
}

func (o *Oauth2) GenerateAuthToken(ctx context.Context, req *AuthorizeRequest) (*token.Token, error) {
	cli, err := o.opts.ClientStore.GetClient(ctx, req.ClientID)
	if err != nil {
		return nil, err
	}else if req.RedirectURI != "" {
		if err := o.ValidateURIHandler(cli.Domain, req.RedirectURI); err != nil {
			return nil, err
		}
	}

	createAt := time.Now()
	token := &token.Token{
		ResponseType:     req.ResponseType,
		ClientID:         req.ClientID,
		UserID:           req.UserID,
		RedirectURI:      req.RedirectURI,
		Scope:            req.Scope,
	}

	switch req.ResponseType {
	case api.Code:
		codeExp := o.opts.codeExp
		if codeExp == 0 {
			codeExp = DefaultCodeExp
		}
		token.CodeCreateAt = createAt
		token.CodeExpiresIn = codeExp

		code, err := o.opts.AuthorizeGenerate.Token(ctx, token)
		if err != nil {
			return nil, err
		}
		token.Code = code
	case api.Token:
		tc := o.opts.tokenConfigs[api.Implicit]
		token.AccessCreateAt = createAt
		token.AccessExpiresIn = tc.AccessTokenExp

		if tc.IsGenerateRefresh {
			token.RefreshCreateAt = createAt
			token.RefreshExpiresIn = tc.RefreshTokenExp
		}

		as, rh, err := o.opts.AccessGenerate.Token(ctx, token, tc.IsGenerateRefresh)
		if err != nil {
			return nil, err
		}
		token.Access = as

		if rh != "" {
			token.Refresh = rh
		}
	}


	if fn := o.ExtensionFieldsHandler; fn != nil {
		token.FieldsValue = fn(token)
	}

	err = o.opts.TokenStore.Create(ctx, token)
	if err != nil {
		return nil, err
	}
	return token, nil
}

func (o *Oauth2) GetAuthorizeToken(ctx context.Context, req *AuthorizeRequest) (*token.Token, error) {
	if fn := o.ClientAuthorizedHandler; fn != nil {
		gt := api.AuthorizationCode
		if req.ResponseType == api.Token {
			gt = api.Implicit
		}

		allowed, err := fn(req.ClientID, gt)
		if err != nil {
			return nil, err
		} else if !allowed {
			return nil, ErrUnauthorizedClient
		}
	}

	if fn := o.ClientScopeHandler; fn != nil {
		allowed, err := fn(req.ClientID, req.Scope)
		if err != nil {
			return nil, err
		} else if !allowed {
			return nil, ErrInvalidScope
		}
	}


	return o.GenerateAuthToken(ctx, req)
}

func (o *Oauth2) ValidationTokenRequest(r *http.Request) (*TokenRequest, error) {
	if v := r.Method; !(v == "POST" ||
		(o.opts.AllowGetAccessRequest && v == "GET")) {
		return nil, ErrInvalidRequest
	}

	gt := api.GrantType(r.FormValue("grant_type"))
	if gt.String() == "" {
		return nil, ErrUnsupportedGrantType
	}

	clientID, clientSecret, err := o.ClientInfoHandler(r)
	if err != nil {
		return nil, err
	}

	tr := &TokenRequest{
		GrantType:    gt,
		ClientID:     clientID,
		ClientSecret: clientSecret,
	}

	switch gt {
	case api.AuthorizationCode:
		tr.RedirectURI = r.FormValue("redirect_uri")
		tr.Code = r.FormValue("code")
		if tr.RedirectURI == "" ||
			tr.Code == "" {
			return nil, ErrInvalidRequest
		}
	case api.PasswordCredentials:
		tr.Scope = r.FormValue("scope")
		username, password := r.FormValue("username"), r.FormValue("password")
		if username == "" || password == "" {
			return nil, ErrInvalidRequest
		}

		userID, err := o.PasswordAuthorizationHandler(username, password)
		if err != nil {
			return nil, err
		} else if userID == "" {
			return nil, ErrInvalidGrant
		}
		tr.UserID = userID
	case api.ClientCredentials:
		tr.Scope = r.FormValue("scope")
	case api.Refreshing:
		tr.Refresh = r.FormValue("refresh_token")
		tr.Scope = r.FormValue("scope")
		if tr.Refresh == "" {
			return nil, ErrInvalidRequest
		}
	}

	return tr, nil
}

func (o *Oauth2) HandleAuthorizeRequest(w http.ResponseWriter, r *http.Request) error {
	ctx := r.Context()

	req, err := o.ValidationAuthorizeRequest(r)
	if err != nil {
		return o.redirectError(w, req, err)
	}

	userID, err := o.UserAuthorizationHandler(w, r)
	if err != nil {
		return o.redirectError(w, req, err)
	} else if userID == "" {
		return nil
	}
	req.UserID = userID

	if fn := o.AuthorizeScopeHandler; fn != nil {
		scope, err := fn(w, r)
		if err != nil {
			return err
		} else if scope != "" {
			req.Scope = scope
		}
	}

	tk, err := o.GetAuthorizeToken(ctx, req)
	if err != nil {
		return o.redirectError(w, req, err)
	}

	if req.RedirectURI == "" {
		client, err := o.opts.ClientStore.GetClient(ctx, req.ClientID)
		if err != nil {
			return err
		}
		req.RedirectURI = client.Domain
	}

	return o.redirect(w, req, tk.GetAuthorizeData())
}

func (o *Oauth2) HandleTokenRequest(w http.ResponseWriter, r *http.Request) error {
	ctx := r.Context()

	tr, err := o.ValidationTokenRequest(r)
	if err != nil {
		return o.outputTokenError(w, err)
	}

	t, err := o.GetAccessToken(ctx, tr)
	if err != nil {
		return o.outputTokenError(w, err)
	}

	return o.outputToken(w, t.BuildToken())
}

func (o *Oauth2) getAuthorizationCode(ctx context.Context, code string) (*token.Token, error) {
	token, err := o.opts.TokenStore.GetTokenByCode(ctx, code)
	if err != nil {
		return nil, err
	} else if token == nil || token.Code != code || token.CodeCreateAt.Add(token.CodeExpiresIn).Before(time.Now()) {
		err = ErrInvalidAuthorizeCode
		return nil, ErrInvalidAuthorizeCode
	}
	return token, nil
}

func (o *Oauth2) getAndDelAuthorizationCode(ctx context.Context, tr *TokenRequest) (*token.Token, error) {
	code := tr.Code
	token, err := o.getAuthorizationCode(ctx, code)
	if err != nil {
		return nil, err
	} else if token.ClientID != tr.ClientID {
		return nil, ErrInvalidAuthorizeCode
	} else if codeURI := token.RedirectURI; codeURI != "" && codeURI != tr.RedirectURI {
		return nil, ErrInvalidAuthorizeCode
	}

	err =  o.opts.TokenStore.RemoveByCode(ctx, code)
	if err != nil {
		return nil, err
	}
	return token, nil
}

func (o *Oauth2) GenerateAccessToken(ctx context.Context, tr *TokenRequest) (*token.Token, error) {
	cli, err := o.opts.ClientStore.GetClient(ctx, tr.ClientID)
	if err != nil {
		return nil, err
	}
	if len(cli.Secret) > 0 && tr.ClientSecret != cli.Secret {
		return nil, ErrInvalidClient
	}

	if tr.RedirectURI != "" {
		if err := o.ValidateURIHandler(cli.Domain, tr.RedirectURI); err != nil {
			return nil, err
		}
	}

	if tr.GrantType == api.AuthorizationCode {
		token, err := o.getAndDelAuthorizationCode(ctx, tr)
		if err != nil {
			return nil, err
		}
		tr.UserID = token.UserID
		tr.Scope = token.Scope
	}

	tc := o.opts.tokenConfigs[tr.GrantType]
	atx := tc.AccessTokenExp
	createAt := time.Now()
	token := &token.Token{
		TokenType:        o.opts.TokenType,
		GrantType:        tr.GrantType,
		ClientID:         tr.ClientID,
		UserID:           tr.UserID,
		RedirectURI:      tr.RedirectURI,
		Scope:            tr.Scope,
		AccessCreateAt:   createAt,
		AccessExpiresIn:  atx,
	}

	av, rv, err := o.opts.AccessGenerate.Token(ctx, token, tc.IsGenerateRefresh)
	if err != nil {
		return nil, err
	}
	token.Access = av

	if tc.IsGenerateRefresh {
		token.RefreshCreateAt = createAt
		token.RefreshExpiresIn = tc.RefreshTokenExp
	}
	if rv != "" {
		token.Refresh = rv
	}

	if fn := o.ExtensionFieldsHandler; fn != nil {
		token.FieldsValue = fn(token)
	}

	err = o.opts.TokenStore.Create(ctx, token)
	if err != nil {
		return nil, err
	}

	return token, nil
}

func (o *Oauth2) RefreshAccessToken(ctx context.Context, tr *TokenRequest) (*token.Token, error) {
	cli, err := o.opts.ClientStore.GetClient(ctx, tr.ClientID)
	if err != nil {
		return nil, err
	} else if tr.ClientSecret != cli.Secret {
		return nil, ErrInvalidClient
	}

	tk, err := o.LoadRefreshToken(ctx, tr.Refresh)
	if err != nil {
		return nil, err
	} else if tk.ClientID != tr.ClientID {
		return nil, ErrInvalidRefreshToken
	}

	createAt := time.Now()
	oldAccess, oldRefresh := tk.Access, tk.Refresh

	token := &token.Token{
		TokenType:        o.opts.TokenType,
		GrantType:	      tr.GrantType,
		ClientID:         tr.ClientID,
		UserID:           tr.UserID,
		RedirectURI:      tr.RedirectURI,
		Scope:            tr.Scope,
		AccessCreateAt:   createAt,
	}

	rc:= DefaultRefreshTokenCfg
	if v := o.opts.refreshConfig; v != nil {
		rc = v
	}

	if v := rc.AccessTokenExp; v > 0 {
		token.AccessExpiresIn = v
	}

	if rc.IsResetRefreshTime {
		token.RefreshCreateAt = createAt
	}

	if v := rc.RefreshTokenExp; v > 0 {
		token.RefreshExpiresIn = v
	}

	if scope := tr.Scope; scope != "" {
		token.Scope = scope
	}

	tv, rv, err := o.opts.AccessGenerate.Token(ctx, token, rc.IsGenerateRefresh)
	if err != nil {
		return nil, err
	}

	token.Access = tv
	if rv != "" {
		token.Refresh = rv
	}

	if fn := o.ExtensionFieldsHandler; fn != nil {
		token.FieldsValue = fn(token)
	}

	if err := o.opts.TokenStore.Create(ctx, token); err != nil {
		return nil, err
	}

	if rc.IsRemoveAccess {
		if err := o.opts.TokenStore.RemoveByAccess(ctx, oldAccess); err != nil {
			return nil, err
		}
	}

	if rc.IsRemoveRefreshing && rv != "" {
		if err := o.opts.TokenStore.RemoveByRefresh(ctx, oldRefresh); err != nil {
			return nil, err
		}
	}

	if rv == "" {
		token.Refresh = ""
		token.RefreshCreateAt = time.Now()
		token.RefreshExpiresIn = 0
	}

	return token, nil
}

func (o *Oauth2) LoadRefreshToken(ctx context.Context, refresh string) (*token.Token, error) {
	if refresh == "" {
		return nil, ErrInvalidRefreshToken
	}

	token, err := o.opts.TokenStore.GetByRefresh(ctx, refresh)
	if err != nil {
		return nil, err
	} else if token == nil || token.Refresh != refresh {
		return nil, ErrInvalidRefreshToken
	} else if token.RefreshExpiresIn != 0 && // refresh token set to not expire
		token.RefreshCreateAt.Add(token.RefreshExpiresIn).Before(time.Now()) {
		return nil, ErrExpiredRefreshToken
	}
	return token, nil
}

func (o *Oauth2) GetAccessToken(ctx context.Context, tr *TokenRequest) (*token.Token, error)  {
	if allowed := o.checkGrantType(tr.GrantType); !allowed {
		return  nil, ErrUnauthorizedClient
	}

	if fn := o.ClientAuthorizedHandler; fn != nil {
		allowed, err := fn(tr.ClientID, tr.GrantType)
		if err != nil {
			return nil, err
		} else if !allowed {
			return nil, ErrUnauthorizedClient
		}
	}

	switch tr.GrantType {
	case api.AuthorizationCode:
		token, err := o.GenerateAccessToken(ctx, tr)
		if err != nil {
			switch err {
			case ErrInvalidAuthorizeCode:
				return  nil, ErrInvalidGrant
			case ErrInvalidClient:
				return  nil, ErrInvalidClient
			default:
				return  nil, err
			}
		}

		return token, nil
	case api.PasswordCredentials, api.ClientCredentials:
		if fn := o.ClientScopeHandler; fn != nil {
			allowed, err := fn(tr.ClientID, tr.Scope)
			if err != nil {
				return nil, err
			} else if !allowed {
				return nil, ErrInvalidScope
			}
		}
		return o.GenerateAccessToken(ctx, tr)
	case api.Refreshing:
		if scope, scopeFn := tr.Scope, o.RefreshingScopeHandler; scope != "" && scopeFn != nil {
			rti, err := o.LoadRefreshToken(ctx, tr.Refresh)
			if err != nil {
				if err == ErrInvalidRefreshToken || err == ErrExpiredRefreshToken {
					return nil, ErrInvalidGrant
				}
				return nil, err
			}

			allowed, err := scopeFn(scope, rti.Scope)
			if err != nil {
				return nil, err
			} else if !allowed {
				return nil, ErrInvalidScope
			}
		}

		ti, err := o.RefreshAccessToken(ctx, tr)
		if err != nil {
			if err == ErrInvalidRefreshToken || err == ErrExpiredRefreshToken {
				return nil, ErrInvalidGrant
			}
			return nil, err
		}
		return ti, nil
	}

	return nil, ErrUnsupportedGrantType
}

func (o *Oauth2) GetRedirectURI(req *AuthorizeRequest, data map[string]interface{}) (string, error) {
	u, err := url.Parse(req.RedirectURI)
	if err != nil {
		return "", err
	}

	q := u.Query()
	if req.State != "" {
		q.Set("state", req.State)
	}

	for k, v := range data {
		q.Set(k, fmt.Sprint(v))
	}

	switch req.ResponseType {
	case api.Code:
		u.RawQuery = q.Encode()
	case api.Token:
		u.RawQuery = ""
		fragment, err := url.QueryUnescape(q.Encode())
		if err != nil {
			return "", err
		}
		u.Fragment = fragment
	}

	return u.String(), nil
}

func (o *Oauth2) redirect(w http.ResponseWriter, req *AuthorizeRequest, data map[string]interface{}) error {
	uri, err := o.GetRedirectURI(req, data)
	if err != nil {
		return err
	}

	w.Header().Set("Location", uri)
	w.WriteHeader(302)
	return nil
}

func (o *Oauth2) redirectError(w http.ResponseWriter, req *AuthorizeRequest, err error) error {
	if req == nil {
		return err
	}
	data, _:= o.errorData(err)
	return o.redirect(w, req, data)
}

func (o *Oauth2) errorData(err error) (map[string]interface{}, int) {
	data := make(map[string]interface{})
	data["error"] = err.Error()

	var statusCode int
	if statusCode = StatusCodes[err]; statusCode == 0 {
		data["error_code"] = statusCode
		statusCode = http.StatusInternalServerError
	}

	if v := Descriptions[err]; v != "" {
		data["error_description"] = v
	}

	return data, statusCode
}

func (o *Oauth2) checkResponseType(rt api.ResponseType) bool {
	for _, art := range o.opts.AllowedResponseTypes {
		if art == rt {
			return true
		}
	}
	return false
}

func (o *Oauth2) checkGrantType(gt api.GrantType) bool {
	for _, agt := range o.opts.AllowedGrantTypes {
		if agt == gt {
			return true
		}
	}
	return false
}

func (o *Oauth2) outputTokenError(w http.ResponseWriter, err error) error {
	data, statusCode := o.errorData(err)
	return o.outputToken(w, data, statusCode)
}

func (o *Oauth2) outputToken(w http.ResponseWriter, data map[string]interface{}, statusCode ...int) error {
	w.Header().Set("Content-Type", "application/json;charset=UTF-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Pragma", "no-cache")

	status := http.StatusOK
	if len(statusCode) > 0 && statusCode[0] > 0 {
		status = statusCode[0]
	}

	w.WriteHeader(status)
	return json.NewEncoder(w).Encode(data)
}

func (o *Oauth2) BearerAuth(r *http.Request) (string, bool) {
	auth := r.Header.Get("Authorization")
	prefix := "Bearer "
	token := ""

	if auth != "" && strings.HasPrefix(auth, prefix) {
		token = auth[len(prefix):]
	} else {
		token = r.FormValue("access_token")
	}

	return token, token != ""
}

func (o *Oauth2) LoadAccessToken(ctx context.Context, access string) (*token.Token, error) {
	if access == "" {
		return nil, ErrInvalidAccessToken
	}

	ct := time.Now()
	tk, err := o.opts.TokenStore.GetByAccess(ctx, access)
	if err != nil {
		return nil, err
	} else if tk == nil || tk.Access != access {
		return nil, ErrInvalidAccessToken
	} else if tk.Refresh != "" && tk.RefreshExpiresIn != 0 &&
		tk.RefreshCreateAt.Add(tk.RefreshExpiresIn).Before(ct) {
		return nil, ErrExpiredRefreshToken
	} else if tk.AccessExpiresIn != 0 &&
		tk.AccessCreateAt.Add(tk.AccessExpiresIn).Before(ct) {
		return nil, ErrExpiredAccessToken
	}
	return tk, nil
}

// ValidationBearerToken validation the bearer tokens
// https://tools.ietf.org/html/rfc6750
func (o *Oauth2) ValidationBearerToken(r *http.Request) (*token.Token, error) {
	ctx := r.Context()

	accessToken, ok := o.BearerAuth(r)
	if !ok {
		return nil, ErrInvalidAccessToken
	}

	return o.LoadAccessToken(ctx, accessToken)
}
