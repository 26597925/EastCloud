package log

type Options struct {
	fields map[string]interface{}
}

type Option func(*Options)

func initOptions() *Options{
	options := &Options{
		fields: make(map[string]interface{}),
	}

	return options
}

func NewOptions(opts ...Option) *Options {
	options := initOptions()
	for _, o := range opts {
		o(options)
	}

	return options
}
