package log

import (
	"fmt"
	"go.uber.org/zap"
)

type zapLog struct {
	cfg  zap.Config
	zap  *zap.Logger
	opts *Options
}

func NewZap (opts *Options) Logger {
	var err error

	zapConfig := zap.NewProductionConfig()
	zapConfig.Level.SetLevel(loggerToZapLevel(InfoLevel))

	log, err := zapConfig.Build(zap.AddCallerSkip(3))
	if err != nil {
		fmt.Println(err)
		return nil
	}

	zl := &zapLog{
		cfg:   zapConfig,
		zap:   log,
		opts:  opts,
	}

	return zl
}

func (z *zapLog) Log(level Level, args ...interface{}) {
	data := make([]zap.Field, 0, len(z.opts.fields))
	for k, v := range z.opts.fields {
		data = append(data, zap.Any(k, v))
	}

	lvl := loggerToZapLevel(level)
	msg := fmt.Sprint(args...)

	switch lvl {
	case zap.DebugLevel:
		z.zap.Debug(msg, data...)
	case zap.InfoLevel:
		z.zap.Info(msg, data...)
	case zap.WarnLevel:
		z.zap.Warn(msg, data...)
	case zap.ErrorLevel:
		z.zap.Error(msg, data...)
	case zap.FatalLevel:
		z.zap.Fatal(msg, data...)
	}
}

func (z *zapLog) Logf(level Level, format string, args ...interface{}){
	data := make([]zap.Field, 0, len(z.opts.fields))
	for k, v := range z.opts.fields {
		data = append(data, zap.Any(k, v))
	}

	lvl := loggerToZapLevel(level)
	msg := fmt.Sprintf(format, args...)
	switch lvl {
	case zap.DebugLevel:
		z.zap.Debug(msg, data...)
	case zap.InfoLevel:
		z.zap.Info(msg, data...)
	case zap.WarnLevel:
		z.zap.Warn(msg, data...)
	case zap.ErrorLevel:
		z.zap.Error(msg, data...)
	case zap.FatalLevel:
		z.zap.Fatal(msg, data...)
	}
}

func (z *zapLog) Info(args ...interface{}) {
	z.Log(InfoLevel, args...)
}

func (z *zapLog) Debug(args ...interface{}) {
	z.Log(DebugLevel, args...)
}

func (z *zapLog) Warn(args ...interface{}) {
	z.Log(WarnLevel, args...)
}

func (z *zapLog) Error(args ...interface{}) {
	z.Log(ErrorLevel, args...)
}

func (z *zapLog) Fatal(args ...interface{}) {
	z.Log(FatalLevel, args...)
}

func (z *zapLog) Type() string {
	return "zap"
}