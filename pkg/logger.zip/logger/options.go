package logger

import (
	"path/filepath"
)

var(
	sp = string(filepath.Separator)
)

type Options struct {
	//zap.Config
	Development   bool
	OutputPaths   []string
	ErrorOutputPaths []string

	LogFileDir    string
	AppName       string
	ErrorFileName string
	WarnFileName  string
	InfoFileName  string
	DebugFileName string
	MaxSize       int
	MaxBackups    int
	MaxAge        int
}

func initOptions() *Options{
	logFileDir , _ := filepath.Abs(filepath.Dir(filepath.Join(".")))
	logFileDir += sp + "logs" + sp

	option := &Options{
		Development:true,
		OutputPaths: []string{"stdout"},
		ErrorOutputPaths:[]string{"stderr"},
		LogFileDir: logFileDir,
		AppName: "app",
		ErrorFileName: "error.logger",
		WarnFileName: "warn.logger",
		InfoFileName: "info.logger",
		DebugFileName: "debug.logger",
		MaxSize: 500,// 500M
		MaxBackups: 3,// 3 backup
		MaxAge: 1,// 1 day
	}

	return option
}

func NewOptions(opts ...Option) *Options {
	options := initOptions()
	for _, o := range opts {
		o(options)
	}

	return options
}

func Development(development bool) Option {
	return func(o *Options) {
		o.Development = development
	}
}

func OutputPaths(outputPaths []string) Option {
	return func(o *Options) {
		o.OutputPaths = outputPaths
	}
}

func ErrorOutputPaths(errorOutputPaths []string) Option {
	return func(o *Options) {
		o.ErrorOutputPaths = errorOutputPaths
	}
}

func LogFileDir(logFileDir string) Option {
	return func(o *Options) {
		o.LogFileDir = logFileDir
	}
}

func AppName(appName string) Option {
	return func(o *Options) {
		o.AppName = appName
	}
}

func ErrorFileName(errorFileName string) Option {
	return func(o *Options) {
		o.ErrorFileName = errorFileName
	}
}

func WarnFileName(warnFileName string) Option {
	return func(o *Options) {
		o.WarnFileName = warnFileName
	}
}

func InfoFileName(infoFileName string) Option {
	return func(o *Options) {
		o.InfoFileName = infoFileName
	}
}

func DebugFileName(debugFileName string) Option {
	return func(o *Options) {
		o.DebugFileName = debugFileName
	}
}

func MaxSize(maxSize int) Option {
	return func(o *Options) {
		o.MaxSize = maxSize
	}
}

func MaxBackups(maxBackups int) Option {
	return func(o *Options) {
		o.MaxBackups = maxBackups
	}
}

func MaxAge(maxAge int) Option {
	return func(o *Options) {
		o.MaxAge = maxAge
	}
}