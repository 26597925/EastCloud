package logger

import (
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"gopkg.in/natefinch/lumberjack.v2"
	"os"
	"sync"
)

var (
	Log *zap.Logger
	m      sync.RWMutex
	isInit bool
)

type Option func(*Options)

func Init(option *Options) (err error) {
	m.Lock()
	defer m.Unlock()

	if isInit {
		return
	}

	zapConfig := zap.NewDevelopmentConfig()
	if !option.Development {
		zapConfig = zap.NewProductionConfig()
	}

	f := func(fN string) zapcore.WriteSyncer {
			return zapcore.AddSync(&lumberjack.Logger{
				Filename:   option.LogFileDir + sp + option.AppName + "-" + fN,
				MaxSize:    option.MaxSize,
				MaxBackups: option.MaxBackups,
				MaxAge:     option.MaxAge,
				Compress:   true,
				LocalTime:  true,
			})
		}
	errWS := f(option.ErrorFileName)
	warnWS := f(option.WarnFileName)
	infoWS := f(option.InfoFileName)
	debugWS := f(option.DebugFileName)

	fileEncoder := zapcore.NewJSONEncoder(zapConfig.EncoderConfig)
	consoleEncoder := zapcore.NewConsoleEncoder(zapConfig.EncoderConfig)

	errPriority := zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl > zapcore.WarnLevel && zapcore.WarnLevel - zapConfig.Level.Level() > -1
	})
	warnPriority := zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.WarnLevel && zapcore.WarnLevel - zapConfig.Level.Level() > -1
	})
	infoPriority := zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.InfoLevel && zapcore.InfoLevel - zapConfig.Level.Level() > -1
	})
	debugPriority := zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.DebugLevel && zapcore.DebugLevel - zapConfig.Level.Level() > -1
	})

	debugConsoleWS := zapcore.Lock(os.Stdout) // 控制台标准输出
	errorConsoleWS := zapcore.Lock(os.Stderr)
	cores := []zapcore.Core{
		zapcore.NewCore(fileEncoder, errWS, errPriority),
		zapcore.NewCore(fileEncoder, warnWS, warnPriority),
		zapcore.NewCore(fileEncoder, infoWS, infoPriority),
		zapcore.NewCore(fileEncoder, debugWS, debugPriority),
		zapcore.NewCore(consoleEncoder, errorConsoleWS, errPriority),
		zapcore.NewCore(consoleEncoder, debugConsoleWS, warnPriority),
		zapcore.NewCore(consoleEncoder, debugConsoleWS, infoPriority),
		zapcore.NewCore(consoleEncoder, debugConsoleWS, debugPriority),
	}

	op := zap.WrapCore(func(c zapcore.Core) zapcore.Core {
			return zapcore.NewTee(cores...)
		})

	Log, err = zapConfig.Build(op)
	if err != nil {
		panic(err)
	}

	defer Log.Sync()

	isInit = true
	return err
}